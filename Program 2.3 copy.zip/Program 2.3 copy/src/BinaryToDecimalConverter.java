import java.util.Scanner;

public class BinaryToDecimalConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a binary number: ");
        String binaryString = scanner.nextLine();

        try {
            int decimalValue = bin2Dec(binaryString);
            System.out.println("Decimal equivalent: " + decimalValue);
        } catch (BinaryFormatException e) {
            System.out.println("Not a binary number: " + e.getMessage());
        }
    }

    public static int bin2Dec(String binaryString) throws BinaryFormatException {
        if (!isBinaryString(binaryString)) {
            throw new BinaryFormatException("Not a binary number");
        }

        int decimalValue = 0;
        int power = 0;

        for (int i = binaryString.length() - 1; i >= 0; i--) {
            if (binaryString.charAt(i) == '1') {
                decimalValue += (int) Math.pow(2, power);
            }
            power++;
        }

        return decimalValue;
    }

    public static boolean isBinaryString(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != '0' && str.charAt(i) != '1') {
                return false;
            }
        }
        return true;
    }
}

class BinaryFormatException extends Exception {
    public BinaryFormatException(String message) {
        super(message);
    }
}
